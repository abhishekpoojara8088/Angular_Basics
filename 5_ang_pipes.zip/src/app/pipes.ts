import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'toCaps'
})
export class ToCapsPipe implements PipeTransform {
  transform(input: string) {
    return input.toUpperCase();
  }
}

