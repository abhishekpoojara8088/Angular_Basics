export interface Person {
    id: number;
    name: string;
    gender?: string;
  }
  
  export const Persons: Person[] = [
    { id: 1, name: 'Abhishek', gender: 'Male'},
    { id: 2, name: 'Nidhi', gender: 'Female' },
    { id: 3, name: 'Aahana', gender: 'Female' },
    { id: 4, name: 'Jay',gender: 'Male'}
  ];
  